let a = document.getElementById("ervinha")
let b = document.getElementById("funguinho")
let c = document.getElementById("trombeteira")
let d = document.getElementById("Ayahuasca")
let e = document.getElementById("Iboga")
let f = document.getElementById("ParreiraBrava")
let im = document.getElementById("natuvel")
a.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"

})
b.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"
})
c.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"
})
d.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"
})
e.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"
})
f.addEventListener("click",function(){
    im.src = "./img]/FBI_headpic-1024x576.jpg"
})